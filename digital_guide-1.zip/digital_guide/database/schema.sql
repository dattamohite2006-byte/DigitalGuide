-- ============================================================
-- Digital Guide for Social and Welfare Schemes
-- Database Schema for MySQL (import via phpMyAdmin / XAMPP)
-- ============================================================

CREATE DATABASE IF NOT EXISTS digital_guide
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE digital_guide;

-- ------------------------------------------------------------
-- Table: users
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(120)  NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    password        VARCHAR(255)  NOT NULL,
    phone           VARCHAR(15)   DEFAULT NULL,
    gender          ENUM('Male','Female','Other') DEFAULT NULL,
    dob             DATE          DEFAULT NULL,
    annual_income   DECIMAL(12,2) DEFAULT NULL,
    category        ENUM('General','OBC','SC','ST','EWS') DEFAULT 'General',
    state            VARCHAR(100)  DEFAULT NULL,
    is_admin        TINYINT(1)    NOT NULL DEFAULT 0,
    created_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: scheme_categories
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scheme_categories (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    name    VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: schemes
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schemes (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    title               VARCHAR(200)  NOT NULL,
    category_id         INT           DEFAULT NULL,
    department          VARCHAR(150)  DEFAULT NULL,
    short_description   VARCHAR(300)  DEFAULT NULL,
    description         TEXT          NOT NULL,
    benefits            TEXT          DEFAULT NULL,
    documents_required  TEXT          DEFAULT NULL,
    how_to_apply        TEXT          DEFAULT NULL,
    official_link       VARCHAR(255)  DEFAULT NULL,
    image               VARCHAR(255)  DEFAULT 'default_scheme.jpg',

    -- Eligibility filters
    min_age             INT           DEFAULT 0,
    max_age             INT           DEFAULT 120,
    max_income          DECIMAL(12,2) DEFAULT NULL,      -- NULL = no income limit
    applicable_gender   ENUM('Male','Female','Other','All') DEFAULT 'All',
    applicable_category ENUM('General','OBC','SC','ST','EWS','All') DEFAULT 'All',
    applicable_state    VARCHAR(100)  DEFAULT 'All',

    status              ENUM('Active','Inactive') DEFAULT 'Active',
    created_by          INT DEFAULT NULL,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (category_id) REFERENCES scheme_categories(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by)  REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: saved_schemes (bookmarks per user)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS saved_schemes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    scheme_id   INT NOT NULL,
    saved_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_save (user_id, scheme_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (scheme_id) REFERENCES schemes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: contact_messages
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contact_messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(120) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    subject     VARCHAR(200) DEFAULT NULL,
    message     TEXT NOT NULL,
    is_read     TINYINT(1) DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- Seed Data
-- ============================================================

-- Default admin account -> email: admin@digitalguide.gov  password: Admin@123
INSERT INTO users (full_name, email, password, is_admin)
VALUES ('System Admin', 'admin@digitalguide.gov',
'scrypt:32768:8:1$M6izYnWrB3KZbHtu$21988ffedddce593d42d83e4462bda498849bc54fd664d1f9b383917ccbf5cef6d461e9aef18bca47bf4627b9582db5ee4c145faed0124ebd1196480c16f9852', 1);

INSERT INTO scheme_categories (name) VALUES
('Education'), ('Health'), ('Employment'), ('Women & Child'),
('Agriculture'), ('Housing'), ('Pension'), ('Disability');

INSERT INTO schemes
(title, category_id, department, short_description, description, benefits, documents_required, how_to_apply, official_link, min_age, max_age, max_income, applicable_gender, applicable_category, applicable_state)
VALUES
('National Scholarship for Higher Education', 1, 'Ministry of Education',
 'Financial assistance for meritorious students from economically weaker sections.',
 'The National Scholarship Scheme provides financial support to students pursuing higher education who belong to economically weaker sections of society, helping reduce the dropout rate.',
 'Up to ₹50,000 per year for tuition and hostel fees.',
 'Aadhaar Card, Income Certificate, Previous Year Marksheet, Bank Passbook',
 'Apply online through the National Scholarship Portal with required documents.',
 'https://scholarships.gov.in', 16, 30, 250000, 'All', 'All', 'All'),

('Ayushman Bharat Health Insurance', 2, 'Ministry of Health & Family Welfare',
 'Free health coverage up to ₹5 lakh per family per year.',
 'A flagship health protection scheme offering free secondary and tertiary care hospitalization to economically vulnerable families.',
 'Cashless treatment up to ₹5,00,000 per family per year at empanelled hospitals.',
 'Aadhaar Card, Ration Card, Income Certificate',
 'Register at the nearest Common Service Centre or apply online.',
 'https://pmjay.gov.in', 0, 120, 300000, 'All', 'All', 'All'),

('Employment Guarantee Scheme (MGNREGA)', 3, 'Ministry of Rural Development',
 'Guaranteed 100 days of wage employment per year for rural households.',
 'Provides at least 100 days of guaranteed wage employment in a financial year to every rural household whose adult members volunteer to do unskilled manual work.',
 'Guaranteed daily wages for up to 100 days annually.',
 'Aadhaar Card, Job Card, Bank Account Details',
 'Register at the local Gram Panchayat office.',
 'https://nrega.nic.in', 18, 60, NULL, 'All', 'All', 'All'),

('Beti Bachao Beti Padhao Scholarship', 4, 'Ministry of Women & Child Development',
 'Support for the girl child''s education and welfare.',
 'A scheme aimed at improving the welfare and education of girl children through financial incentives and awareness programs.',
 'One-time grant of ₹25,000 and periodic scholarships till graduation.',
 'Birth Certificate, Aadhaar Card, School Enrollment Proof',
 'Apply through the local Anganwadi centre or online women welfare portal.',
 'https://wcd.nic.in', 0, 21, 200000, 'Female', 'All', 'All'),

('PM Kisan Samman Nidhi', 5, 'Ministry of Agriculture',
 'Direct income support of ₹6,000 per year to farmer families.',
 'Provides income support to all landholding farmer families to supplement their financial needs for agriculture inputs.',
 '₹6,000 per year in three equal installments directly to bank account.',
 'Aadhaar Card, Land Records, Bank Passbook',
 'Apply online via the PM-Kisan portal or nearest Common Service Centre.',
 'https://pmkisan.gov.in', 18, 120, NULL, 'All', 'All', 'All'),

('Housing for All (Urban) Scheme', 6, 'Ministry of Housing & Urban Affairs',
 'Interest subsidy on home loans for economically weaker sections.',
 'Aims to provide affordable pucca housing to all eligible urban households through credit-linked subsidy on home loans.',
 'Interest subsidy up to 6.5% on home loans for a tenure of 20 years.',
 'Aadhaar Card, Income Certificate, Property Documents',
 'Apply through empanelled banks or the official PMAY-U portal.',
 'https://pmaymis.gov.in', 21, 65, 600000, 'All', 'All', 'All'),

('Old Age Pension Scheme', 7, 'Ministry of Social Justice & Empowerment',
 'Monthly pension for senior citizens below the poverty line.',
 'Provides monthly financial assistance to senior citizens living below the poverty line who have no regular means of income.',
 'Monthly pension of ₹1,000 to ₹2,000 depending on state.',
 'Aadhaar Card, Age Proof, BPL Certificate',
 'Apply at the district Social Welfare Office.',
 'https://nsap.nic.in', 60, 120, 100000, 'All', 'All', 'All'),

('Disability Support & Assistive Devices Scheme', 8, 'Ministry of Social Justice & Empowerment',
 'Free assistive devices and monthly allowance for persons with disabilities.',
 'Provides financial aid and free assistive devices such as wheelchairs and hearing aids to persons with 40% or more disability.',
 'Free assistive devices and monthly allowance of ₹1,500.',
 'Aadhaar Card, Disability Certificate, Income Certificate',
 'Apply at the district Disability Welfare Office or online portal.',
 'https://disabilityaffairs.gov.in', 5, 120, 150000, 'All', 'All', 'All');
